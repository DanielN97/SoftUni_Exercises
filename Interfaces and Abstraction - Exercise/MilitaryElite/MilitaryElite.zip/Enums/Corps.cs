﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MilitaryElite.Enums
{
    public enum Corps
    {
        Airforces,
        Marines
    }
}
